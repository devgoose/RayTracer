#include "Scene.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>



using namespace std;

#include "Sphere.h"
#include "PointLight.h"
#include "DirectionalLight.h"

Scene::~Scene() {
	for (unsigned int i = 0; i < objects.size(); i++) {
		delete objects[i];
	}
}

bool Scene::populate(string filename) {
	ifstream fin;
	fin.open(filename);
	if (!fin.is_open()) {
		cout << "Error opening file.";
		return false;
	}

	// Continue to read file

	string line;
	int line_number = 0;
	Material mtlcolor = Material();

	while (getline(fin, line)) {
		stringstream ss = stringstream(line);
		string keyword;

		ss >> keyword;

		cout << "Reading line: " << line_number << "   " << keyword << endl;

		if (keyword.compare("eye") == 0) {
			float x, y, z;
			ss >> x >> y >> z;
			if (!ss) {
				cout << "Failure reading input for eye on line: " << line_number << endl;
				return false;
			}
			eye = Point3(x, y, z);
		}
		else if (keyword.compare("updir") == 0) {
			float x, y, z;
			ss >> x >> y >> z;
			if (!ss) {
				cout << "Failure reading input for updir on line: " << line_number << endl;
				return false;
			}
			updir = Vector3(x, y, z).toUnit();
		}
		else if (keyword.compare("viewdir") == 0) {
			float x, y, z;
			ss >> x >> y >> z;
			if (!ss) {
				cout << "Failure reading input for viewdir on line: " << line_number << endl;
				return false;
			}
			viewdir = Vector3(x, y, z).toUnit();
		}
		else if (keyword.compare("hfov") == 0) {
			float hfov;
			ss >> hfov;
			if (!ss) {
				cout << "Failure reading input for hfov on line: " << line_number << endl;
				return false;
			}
			fov_h = hfov;
		}
		else if (keyword.compare("imsize") == 0) {
			int width, height;
			ss >> width >> height;
			if (!ss) {
				cout << "Failure reading input for imsize on line: " << line_number << endl;
				return false;
			}
			img_width = width;
			img_height = height;
		}
		else if (keyword.compare("bkgcolor") == 0) {
			float r, g, b;
			ss >> r >> g >> b;
			if (!ss) {
				cout << "Failure reading input for bkgcolor on line: " << line_number << endl;
				return false;
			}
			bkgcolor = Color(r, g, b);
		}
		else if (keyword.compare("mtlcolor") == 0) {
			float rd, gd, bd, rs, gs, bs, ka, kd, ks, n;
			ss >> rd >> gd >> bd >> rs >> gs >> bs >> ka >> kd >> ks >> n;
			if (!ss) {
				cout << "Failure reading input for mtlcolor on line: " << line_number << endl;
				return false;
			}
			Color diff = Color(rd, gd, bd);
			Color spec = Color(rs, gs, bs);
			mtlcolor = Material(diff, spec, ka, kd, ks, n);
		}
		else if (keyword.compare("sphere") == 0) {
			float x, y, z, r;
			ss >> x >> y >> z >> r;
			if (!ss) {
				cout << "Failure reading input for sphere on line: " << line_number << endl;
				return false;
			}
			Point3 p = Point3(x, y, z);
			SceneObject* so = new Sphere(p, r, mtlcolor);
			objects.push_back(so);
		}
		else if (keyword.compare("light") == 0 || keyword.compare("attlight") == 0) {
			float x, y, z, r, g, b, c1, c2, c3;
			int w;
			if (keyword.compare("attlight") == 0) {
				ss >> x >> y >> z >> w >> r >> g >> b >> c1 >> c2 >> c3;
			}
			else {
				ss >> x >> y >> z >> w >> r >> g >> b;
			}
			if (!ss) {
				cout << "Failure reading input for color on line: " << line_number << endl;
				return false;
			}
			if (w != 0 && w != 1) {
				cout << "Failure reading input for color on line: " << line_number << endl;
				cout << "'w' value must be either 0 or 1" << endl;
				return false;
			}
			Color c = Color(r, g, b);
			Light* l;

			// Point Light
			if (w == 1) {
				l = new PointLight(c, Point3(x, y, z));
			}
			else {
				l = new DirectionalLight(c, Vector3(x, y, z));
			}

			// Attenuate light if applicable
			if (keyword.compare("attlight") == 0) {
				l->attenuate(c1, c2, c3);
			}
			lights.push_back(l);
		}
		else if (keyword.compare("depthcueing") == 0) {
			float r, g, b, amax, amin, distmax, distmin;
			ss >> r >> g >> b >> amax >> amin >> distmax >> distmin;
			if (!ss) {
				cout << "Failure reading input for depthcueing on line: " << line_number << endl;
				return false;
			}
			Color c = Color(r, g, b);
			depthCue = DepthCue(c, amax, amin, distmax, distmin);
			depthCued = true;
		}
		else {
			// Weird input, Continue
		}

		line_number++;
	}

	fin.close();

	return true;
}